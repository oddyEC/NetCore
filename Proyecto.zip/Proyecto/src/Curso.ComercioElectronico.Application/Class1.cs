﻿namespace Curso.ComercioElectronico.Application;
public class Class1
{

}
