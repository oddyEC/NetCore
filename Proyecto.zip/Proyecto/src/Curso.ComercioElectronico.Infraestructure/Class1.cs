﻿namespace Curso.ComercioElectronico.Infraestructure;

/* public class ComercioElectronicoDbContext:DbContext
{

} */



