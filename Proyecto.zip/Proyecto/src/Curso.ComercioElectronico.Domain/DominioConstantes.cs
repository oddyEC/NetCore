namespace Curso.ComercioElectronico.Domain;



public static class DominioConstantes{
    
    public const int NOMBRE_MAXIMO = 80;

}